package servlet1;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.*;
import mainJava.admin;

/**
 * Servlet implementation class servlet1
 */
@WebServlet("/servlet1")
public class servlet1 extends HttpServlet {
	public List<transactionBean> tbn = new ArrayList<transactionBean>();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public servlet1() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		/* response.setContentType("text/HTML"); */
		PrintWriter out = response.getWriter();
		List<ArrayList> tbn2 = new ArrayList<ArrayList>();
		String username = "";
		String password = "";
		double limit = 0.0;
		double def_bal = 0.0;
		String button = request.getParameter("operation");
		admin login = new admin();

		budgetPlanningBean bg = new budgetPlanningBean();
		HttpSession session = request.getSession();
		try {
			if (button.equalsIgnoreCase("login")) {
				username = request.getParameter("userName");
				password = request.getParameter("password");
				session.setAttribute("messages", "");
				if (login.loginCheck(username, password) == true) {
					session.setAttribute("name", username);
					request.setAttribute("Message", "Success");
					if (null == session.getAttribute("balance")) {
						session.setAttribute("balance", 200.0);
						session.setAttribute("limit", null);
					}
					System.out.println(session.getAttribute("balance"));
					response.sendRedirect("home.jsp");
				} else {
					session.setAttribute("messages", "Invalid Credentials");
					response.sendRedirect("login.jsp");
				}
			}

			if (button.equalsIgnoreCase("Update")) {
				session.setAttribute("messages", "");
				String reg = request.getParameter("register");
				double dl = 0.0;
				if (reg.equalsIgnoreCase("register")) {
					if (!request.getParameter("dailylimit").equalsIgnoreCase("")) {
						limit = Double.parseDouble(request.getParameter("dailylimit"));
						homeBean hb = login.accountDetail();
						if (hb.getBalanceAmount() >= limit) {
							if (session.getAttribute("Daylimit") != null) {
								dl = (Double) session.getAttribute("Daylimit");
							}
							session.setAttribute("Daylimit", limit);

							bg.setDailyLimit(limit);
							if (session.getAttribute("limit") == null) {
								session.setAttribute("limit", limit);
								session.setAttribute("messages", "Updated budget plan successfully");
							} else if (session.getAttribute("def_bal") != null) {
								System.out.println("Daylimit" + (Double) session.getAttribute("Daylimit"));
								System.out.println("def_bal" + (Double) session.getAttribute("def_bal"));
								System.out.println("limit" + (Double) session.getAttribute("limit"));
								System.out.println("dl" + dl);

								if ((Double) session.getAttribute("Daylimit") > (Double) session
										.getAttribute("def_bal")) {
									if ((Double) session.getAttribute("def_bal") > 0.0
											&& (Double) session.getAttribute("limit") == 0.0) {
										double x = (Double) session.getAttribute("limit")
												+ ((Double) session.getAttribute("Daylimit")
														- (Double) session.getAttribute("def_bal"));
										session.setAttribute("limit", x);
										session.setAttribute("messages", "Updated budget plan successfully");
									} else {
										double x = (Double) session.getAttribute("limit")
												+ ((Double) session.getAttribute("Daylimit") - dl);
										session.setAttribute("limit", x);
										session.setAttribute("messages", "Updated budget plan successfully");
									}
								} else {
									session.setAttribute("Daylimit", dl);
									session.setAttribute("messages",
											"Please enter daily limit greater than today's transactions");
								}

							}
						}
					}
				} else if (reg.equalsIgnoreCase("Deregister")) {
					bg.setDailyLimit(0.0);
					session.setAttribute("limit", 0.0);
					session.setAttribute("Daylimit", null);
					session.setAttribute("messages", "Budget plan deregistered successfully");
				}
				response.sendRedirect("budgetplanner.jsp");
			}
			if (button.equalsIgnoreCase("Transfer")) {
				double bal = 0.0;
				session.setAttribute("messages", "");
				if (session.getAttribute("balance") != null) {
					bal = (double) session.getAttribute("balance");
				}
				if (!request.getParameter("txnAmount").equalsIgnoreCase("")) {
					// limit=Double.parseDouble(request.getParameter("dailylimit"));
					double txnAmount = 0;
					txnAmount = Double.parseDouble(request.getParameter("txnAmount"));
					String accnumTxn = request.getParameter("toAccount");
					double new_bal = 0.0;

					if (bal > txnAmount) {
						Date dt = Calendar.getInstance().getTime();
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
						if (null != session.getAttribute("limit")) {
							session.setAttribute("limit", (double) session.getAttribute("limit") - txnAmount);
						}
						transactionBean tb = new transactionBean();
						new_bal = bal - txnAmount;
						if (session.getAttribute("def_bal") != null) {
							session.setAttribute("def_bal", (double) session.getAttribute("def_bal") + txnAmount);
						} else {
							session.setAttribute("def_bal", txnAmount);
						}
						session.setAttribute("balance", new_bal);
						List<String> tbn1 = new ArrayList<String>();
						tbn1.add(request.getParameter("txnAmount"));
						tbn1.add(request.getParameter("toAccount"));
						tbn1.add(sdf.format(dt));
						tbn1.add(String.valueOf(new_bal));
						if (null != session.getAttribute("lis")) {
							tbn2 = (List<ArrayList>) session.getAttribute("lis");
						}
						tbn2.add((ArrayList) tbn1);
						session.setAttribute("lis", tbn2);
						response.sendRedirect("fundtransfer.jsp");
						session.setAttribute("messages", "Amount is transfered successfully");
					}
				}
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
