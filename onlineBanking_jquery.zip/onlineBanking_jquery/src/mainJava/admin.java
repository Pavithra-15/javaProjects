package mainJava;
import javax.servlet.http.HttpSession;

import bean.*;
public class admin {
	//HttpSession session=Request.getSession();
	public boolean loginCheck(String user,String pass) {
		loginBean login=new loginBean();
		login.setUserName();
		login.setPassword();
		System.out.println("user"+user+"pass"+pass);
		if(user.equals(login.getUserName())&&pass.equals(login.getPassword())) {
			return true;
			}
		return false;	
	}
	public homeBean accountDetail()
	{
		homeBean hb=new homeBean();
		hb.setAccountNumber();
		hb.setAccountType();
		hb.setBalanceAmount();
		//session.setAttribute("balance",hb.getBalanceAmount());
		return hb;
	}
	public budgetPlanningBean kittyDetail(double limit)
	{
		budgetPlanningBean bg=new budgetPlanningBean();
		bg.setDailyLimit(limit);
		return bg;
	}
	public void transfer() {
		
		
	}
	public void main() {
		
	}
}
