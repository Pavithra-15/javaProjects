package bean;

public class transactionBean {
String accNum_txn;
String data_txn;
double bal_txn;
double txnAmt;
int transactionNumber=000;
public int getTransactionNumber() {
	return transactionNumber;
}
public void setTransactionNumber(int transactionNumber) {
	this.transactionNumber = transactionNumber;
}
public double getTxnAmt() {
	return txnAmt;
}
public void setTxnAmt(double txnAmt) {
	this.txnAmt = txnAmt;
}
public String getAccNum_txn() {
	return accNum_txn;
}
public void setAccNum_txn(String accNum_txn) {
	this.accNum_txn = accNum_txn;
}
public String getData_txn() {
	return data_txn;
}
public void setData_txn(String data_txn) {
	this.data_txn = data_txn;
}
public double getBal_txn() {
	return bal_txn;
}
public void setBal_txn(double bal_txn) {
	this.bal_txn = bal_txn;
}

}
