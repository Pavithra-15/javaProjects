package bean;

public class loginBean {
public String userName;
public String password;
public String getUserName() {
	return userName;
}
public void setUserName() {
	this.userName = "testuser";
}
public String getPassword() {
	return password;
}
public void setPassword() {
	this.password = "testuser123";
}

}
