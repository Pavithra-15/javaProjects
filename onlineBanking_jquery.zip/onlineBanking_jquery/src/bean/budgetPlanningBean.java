package bean;

public class budgetPlanningBean {
public double dailyLimit;

public double getDailyLimit() {
	return dailyLimit;
}

public void setDailyLimit(double dailyLimit) {
	this.dailyLimit = dailyLimit;
}

}
