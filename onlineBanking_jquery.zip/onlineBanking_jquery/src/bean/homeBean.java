package bean;

public class homeBean {
	 public String accountNumber;
	 public String accountType;
	 public double balanceAmount;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber() {
		this.accountNumber = "1234567890";
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType() {
		this.accountType = "Savings" ;
	}
	public double getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount() {
		this.balanceAmount = 200;
	}
}
